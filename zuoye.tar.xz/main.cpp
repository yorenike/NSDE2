#include <iostream>
#include <iomanip>
#include <cmath>
#include "Grid1D.h"
#include "Restrictor.h"
#include "Prolongator.h"
#include "Smoother.h"
#include "VCycle.h"
#include "FMG.h"
#include "TestFunction.h"
#include "JSONParser.h"

// 计算误差（最大范数）
double computeError(const std::vector<double>& u, 
                    std::shared_ptr<Grid1D> grid,
                    const TestFunction& tf) {
    double error = 0.0;
    for (int i = 0; i <= grid->getN(); i++) {
        double x = grid->getX(i);
        double u_exact = tf.exact1D(x);
        error = std::max(error, std::abs(u[i] - u_exact));
    }
    return error;
}

// 计算收敛率
double computeConvergenceRate(double error1, double error2, double h1, double h2) {
    return std::log(error1 / error2) / std::log(h1 / h2);
}

int main(int argc, char* argv[]) {
    std::cout << "========================================" << std::endl;
    std::cout << " 1D Multigrid Solver for Poisson Equation" << std::endl;
    std::cout << "========================================" << std::endl;
    
    // 读取配置文件
    std::string config_file = "input.json";
    if (argc > 1) {
        config_file = argv[1];
    }
    
    JSONParser parser(config_file);
    
    // 获取参数
    int n = parser.getInt("grid.n");
    std::string test_name = parser.getString("test_function.name");
    std::string restriction_type = parser.getString("multigrid.restriction");
    std::string interpolation_type = parser.getString("multigrid.interpolation");
    std::string cycle_type = parser.getString("multigrid.cycle");
    int nu1 = parser.getInt("multigrid.nu1");
    int nu2 = parser.getInt("multigrid.nu2");
    double epsilon = parser.getDouble("multigrid.epsilon");
    int max_iter = parser.getInt("multigrid.max_iter");
    
    std::cout << "\nConfiguration:" << std::endl;
    std::cout << "  n = " << n << std::endl;
    std::cout << "  test_function = " << test_name << std::endl;
    std::cout << "  restriction = " << restriction_type << std::endl;
    std::cout << "  interpolation = " << interpolation_type << std::endl;
    std::cout << "  cycle = " << cycle_type << std::endl;
    std::cout << "  nu1 = " << nu1 << ", nu2 = " << nu2 << std::endl;
    std::cout << "  epsilon = " << epsilon << std::endl;
    
    // 创建测试函数
    TestFunction tf(test_name);
    
    // 创建网格
    auto grid = std::make_shared<Grid1D>(n, 0.0, 1.0);
    
    // 构建右端项 f
    std::vector<double> f(grid->getNumTotal(), 0.0);
    for (int i = 1; i < n; i++) {
        double x = grid->getX(i);
        f[i] = tf.f1D(x);
    }
    // 边界点：f 的值不重要，因为 Dirichlet 条件会覆盖
    f[0] = 0.0;
    f[n] = 0.0;
    
    // 选择限制算子
    Restrictor restrictor;
    if (restriction_type == "injection") {
        // 需要实现 InjectionRestrictor
        std::cout << "Warning: Injection not fully implemented, using full weighting" << std::endl;
    }
    
    // 选择延拓算子
    Prolongator prolongator;
    if (interpolation_type == "quadratic") {
        // 需要实现 QuadraticProlongator
        std::cout << "Warning: Quadratic interpolation not fully implemented, using linear" << std::endl;
    }
    
    // 创建平滑算子、V-cycle、FMG
    Smoother smoother(2.0/3.0);
    VCycle vcycle(restrictor, prolongator, smoother);
    FMG fmg(restrictor, prolongator, smoother, vcycle);
    
    // 求解
    std::cout << "\nSolving..." << std::endl;
    std::vector<double> u;
    
    if (cycle_type == "FMG") {
        u = fmg.solve(f, grid, nu1, nu2);
    } else {
        // V-cycle 需要多次迭代
        u = std::vector<double>(grid->getNumTotal(), 0.0);
        for (int iter = 0; iter < max_iter; iter++) {
            u = vcycle.solve(u, f, grid, nu1, nu2);
            
            // 检查收敛
            std::vector<double> r = smoother.matVec(u, grid);
            double residual_norm = 0.0;
            for (size_t i = 0; i < r.size(); i++) {
                double diff = f[i] - r[i];
                residual_norm += diff * diff;
            }
            residual_norm = std::sqrt(residual_norm);
            
            if (residual_norm < epsilon) {
                std::cout << "  Converged after " << iter + 1 << " V-cycles" << std::endl;
                break;
            }
        }
    }
    
    // 计算误差
    double error = computeError(u, grid, tf);
    std::cout << "\nResult:" << std::endl;
    std::cout << "  Max error = " << std::scientific << error << std::endl;
    
    // 输出部分结果
    std::cout << "\nSolution at selected points:" << std::endl;
    std::cout << std::fixed << std::setprecision(6);
    for (int i = 0; i <= n; i += n/8) {
        double x = grid->getX(i);
        double u_exact = tf.exact1D(x);
        std::cout << "  x = " << x << ": numerical = " << u[i] 
                  << ", exact = " << u_exact 
                  << ", error = " << std::abs(u[i] - u_exact) << std::endl;
    }
    
    // 收敛率测试（多个网格）
    std::cout << "\n========================================" << std::endl;
    std::cout << "Convergence Rate Test" << std::endl;
    std::cout << "========================================" << std::endl;
    
    std::vector<int> ns = {16, 32, 64, 128};
    std::vector<double> errors;
    
    for (int n_test : ns) {
        auto grid_test = std::make_shared<Grid1D>(n_test, 0.0, 1.0);
        
        std::vector<double> f_test(grid_test->getNumTotal(), 0.0);
        for (int i = 1; i < n_test; i++) {
            double x = grid_test->getX(i);
            f_test[i] = tf.f1D(x);
        }
        
        FMG fmg_test(restrictor, prolongator, smoother, vcycle);
        std::vector<double> u_test = fmg_test.solve(f_test, grid_test, nu1, nu2);
        
        double err = computeError(u_test, grid_test, tf);
        errors.push_back(err);
        
        std::cout << "n = " << n_test << ": error = " << std::scientific << err << std::endl;
    }
    
    // 计算收敛率
    std::cout << "\nConvergence rates:" << std::endl;
    for (size_t i = 1; i < ns.size(); i++) {
        double h1 = 1.0 / ns[i-1];
        double h2 = 1.0 / ns[i];
        double rate = computeConvergenceRate(errors[i-1], errors[i], h1, h2);
        std::cout << "  " << ns[i-1] << " -> " << ns[i] << ": rate = " 
                  << std::fixed << std::setprecision(2) << rate << std::endl;
    }
    
    std::cout << "\n========================================" << std::endl;
    std::cout << "Done!" << std::endl;
    std::cout << "========================================" << std::endl;
    
    return 0;
}
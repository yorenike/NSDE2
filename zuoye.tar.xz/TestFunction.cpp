#include "TestFunction.h"

// ========== 测试函数1: exp(y + sin(x)) ==========
void TestFunction::initExpYSinX() {
    name = "exp_y_sin_x";
    
    // 解析解
    u_func = [](double x, double y) {
        return std::exp(y + std::sin(x));
    };
    
    // 右端项 f = -Δu
    // Δu = exp(y + sin(x)) * (cos²x - sin x + 1)
    f_func = [](double x, double y) {
        double u = std::exp(y + std::sin(x));
        double cosx = std::cos(x);
        return -u * (cosx * cosx - std::sin(x) + 1.0);
    };
    
    // Dirichlet 边界条件
    bc_left   = [](double x, double y) { return std::exp(y + std::sin(0.0)); };
    bc_right  = [](double x, double y) { return std::exp(y + std::sin(1.0)); };
    bc_bottom = [](double x, double y) { return std::exp(0.0 + std::sin(x)); };
    bc_top    = [](double x, double y) { return std::exp(1.0 + std::sin(x)); };
}

// ========== 测试函数2: 多项式 u(x,y) = x²(1-x)² y²(1-y)² ==========
void TestFunction::initPolynomial() {
    name = "polynomial";
    
    u_func = [](double x, double y) {
        double A = x * x * (1.0 - x) * (1.0 - x);
        double B = y * y * (1.0 - y) * (1.0 - y);
        return A * B;
    };
    
    f_func = [](double x, double y) {
        // A(x) = x² - 2x³ + x⁴
        // A''(x) = 2 - 12x + 12x²
        // B(y) = y² - 2y³ + y⁴
        // B''(y) = 2 - 12y + 12y²
        double A = x*x - 2.0*x*x*x + x*x*x*x;
        double App = 2.0 - 12.0*x + 12.0*x*x;
        double B = y*y - 2.0*y*y*y + y*y*y*y;
        double Bpp = 2.0 - 12.0*y + 12.0*y*y;
        return -(App * B + A * Bpp);
    };
    
    // Dirichlet 边界条件：边界上 u = 0
    bc_left = bc_right = bc_bottom = bc_top = [](double, double) { return 0.0; };
}

// ========== 测试函数3: 三角函数 u(x,y) = sin(πx) sin(πy) ==========
void TestFunction::initTrigonometric() {
    name = "trigonometric";
    
    u_func = [](double x, double y) {
        return std::sin(M_PI * x) * std::sin(M_PI * y);
    };
    
    f_func = [](double x, double y) {
        return 2.0 * M_PI * M_PI * std::sin(M_PI * x) * std::sin(M_PI * y);
    };
    
    // Dirichlet 边界条件：边界上 u = 0
    bc_left = bc_right = bc_bottom = bc_top = [](double, double) { return 0.0; };
}

// ========== 构造函数 ==========
TestFunction::TestFunction(const std::string& name_) {
    if (name_ == "exp_y_sin_x") {
        initExpYSinX();
    }
    else if (name_ == "polynomial") {
        initPolynomial();
    }
    else if (name_ == "trigonometric") {
        initTrigonometric();
    }
    else {
        throw std::runtime_error("Unknown test function: " + name_);
    }
}

// ========== 公共接口实现 ==========
double TestFunction::exact(double x, double y) const {
    return u_func(x, y);
}

double TestFunction::f(double x, double y) const {
    return f_func(x, y);
}

double TestFunction::getDirichletBC(double x, double y, const std::string& side) const {
    if (side == "left")   return bc_left(x, y);
    if (side == "right")  return bc_right(x, y);
    if (side == "bottom") return bc_bottom(x, y);
    if (side == "top")    return bc_top(x, y);
    throw std::runtime_error("Unknown side: " + side);
}
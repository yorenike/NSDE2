#include "VCycle.h"
#include "LinearSolver.h"
#include <iostream>

// 不要在这里定义构造函数！已经在 VCycle.h 中内联定义了

std::vector<double> VCycle::solve(std::vector<double> u,
                                    const std::vector<double>& f,
                                    std::shared_ptr<Grid1D> grid,
                                    int nu1, int nu2) const {
    
    int n = grid->getN();
    int N_total = grid->getNumTotal();
    
    // ========== 1. 预平滑 ==========
    u = smoother(u, f, grid, nu1);
    
    // ========== 2. 最粗网格：直接求解 ==========
    if (grid->isCoarsest()) {
        double h = grid->getH();
        double inv_h2 = 1.0 / (h * h);
        
        // 构建矩阵 A
        std::vector<std::vector<double>> A(N_total, std::vector<double>(N_total, 0.0));
        std::vector<double> rhs = f;
        
        // 内部点：-u'' 的离散
        for (int i = 1; i < n; i++) {
            A[i][i-1] = -inv_h2;
            A[i][i]   =  2.0 * inv_h2;
            A[i][i+1] = -inv_h2;
        }
        
        // 边界点：Dirichlet 条件 u = 0
        A[0][0] = 1.0;
        A[n][n] = 1.0;
        rhs[0] = 0.0;
        rhs[n] = 0.0;
        
        // 调用高斯消元求解
        return LinearSolver::gaussianElimination(A, rhs);
    }
    
    // ========== 3. 计算残差 ==========
    std::vector<double> Au = smoother.matVec(u, grid);
    std::vector<double> r(N_total, 0.0);
    for (int i = 0; i < N_total; i++) {
        r[i] = f[i] - Au[i];
    }
    
    // ========== 4. 限制残差到粗网格 ==========
    auto coarse = grid->getCoarseGrid();
    std::vector<double> r_coarse = restrictor(r, grid, coarse);
    
    // ========== 5. 在粗网格上递归求解残差方程 ==========
    std::vector<double> e_coarse(coarse->getNumTotal(), 0.0);
    e_coarse = solve(e_coarse, r_coarse, coarse, nu1, nu2);
    
    // ========== 6. 延拓误差并校正 ==========
    std::vector<double> e = prolongator(e_coarse, coarse, grid);
    for (int i = 0; i < N_total; i++) {
        u[i] += e[i];
    }
    
    // ========== 7. 后平滑 ==========
    u = smoother(u, f, grid, nu2);
    
    return u;
}
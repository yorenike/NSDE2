#include <iostream>
#include <iomanip>
#include <cmath>
#include <memory>
#include "Grid1D.h"
#include "Restrictor.h"
#include "Prolongator.h"
#include "Smoother.h"
#include "VCycle.h"
#include "FMG.h"
#include "TestFunction.h"
#include "JSONParser.h"

// 计算误差（最大范数）
double computeError(const std::vector<double>& u, 
                    std::shared_ptr<Grid1D> grid,
                    const TestFunction1D& tf) {
    double error = 0.0;
    for (int i = 0; i <= grid->getN(); i++) {
        double x = grid->getX(i);
        double u_exact = tf.exact(x);
        error = std::max(error, std::abs(u[i] - u_exact));
    }
    return error;
}

// 计算收敛率
double computeConvergenceRate(double error1, double error2, double h1, double h2) {
    return std::log(error1 / error2) / std::log(h1 / h2);
}

int main(int argc, char* argv[]) {
    std::cout << "========================================" << std::endl;
    std::cout << " 1D Multigrid Solver for Poisson Equation" << std::endl;
    std::cout << "========================================" << std::endl;
    
    // 读取配置文件
    std::string config_file = "input.json";
    if (argc > 1) {
        config_file = argv[1];
    }
    
    JSONParser parser(config_file);
    
    // 获取参数
    int n = parser.getInt("grid.n");
    std::string test_name = parser.getString("test_function.name");
    std::string left_type = parser.getString("boundary.left.type");
    std::string right_type = parser.getString("boundary.right.type");
    std::string restriction_type = parser.getStringOrDefault("multigrid.restriction", "full_weighting");
    std::string interpolation_type = parser.getStringOrDefault("multigrid.interpolation", "linear");
    std::string cycle_type = parser.getStringOrDefault("multigrid.cycle", "FMG");
    int nu1 = parser.getIntOrDefault("multigrid.nu1", 2);
    int nu2 = parser.getIntOrDefault("multigrid.nu2", 2);
    double epsilon = parser.getDoubleOrDefault("multigrid.epsilon", 1e-8);
    int max_iter = parser.getIntOrDefault("multigrid.max_iter", 100);
    
    std::cout << "\nConfiguration:" << std::endl;
    std::cout << "  n = " << n << std::endl;
    std::cout << "  test_function = " << test_name << std::endl;
    std::cout << "  left boundary: " << left_type << std::endl;
    std::cout << "  right boundary: " << right_type << std::endl;
    std::cout << "  restriction = " << restriction_type << std::endl;
    std::cout << "  interpolation = " << interpolation_type << std::endl;
    std::cout << "  cycle = " << cycle_type << std::endl;
    std::cout << "  nu1 = " << nu1 << ", nu2 = " << nu2 << std::endl;
    std::cout << "  epsilon = " << epsilon << std::endl;
    
    // 创建测试函数和网格
    TestFunction1D tf(test_name);
    auto grid = std::make_shared<Grid1D>(n, 0.0, 1.0);
    double h = grid->getH();
    
    // ========== 获取边界值（从测试函数） ==========
    double left_dirichlet = tf.exact(0.0);
    double right_dirichlet = tf.exact(1.0);
    double left_neumann = -tf.du(0.0);
    double right_neumann = tf.du(1.0);
    
    std::cout << "\nBoundary values (from test function):" << std::endl;
    std::cout << "  u(0) = " << left_dirichlet << ", u'(0) = " << left_neumann << std::endl;
    std::cout << "  u(1) = " << right_dirichlet << ", u'(1) = " << right_neumann << std::endl;
    
    // ========== 构建右端项 b（原问题） ==========
    std::vector<double> b(grid->getNumTotal(), 0.0);
    
    // 内部节点 (i = 1, ..., n-1)
    for (int i = 1; i < n; i++) {
        double x = grid->getX(i);
        b[i] = tf.f(x);
    }
    
    // 左边界 (i = 0)
    double x0 = grid->getX(0);
    if (left_type == "dirichlet") {
        b[0] = left_dirichlet;
    } else if (left_type == "neumann") {
        b[0] = tf.f(x0) + 2.0 * left_neumann / h;
    }
    
    // 右边界 (i = n)
    double xn = grid->getX(n);
    if (right_type == "dirichlet") {
        b[n] = right_dirichlet;
    } else if (right_type == "neumann") {
        b[n] = tf.f(xn) + 2.0 * right_neumann / h;
    }
    
    // ========== 初始猜测（全为 0） ==========
    std::vector<double> u(grid->getNumTotal(), 0.0);
    
    // ========== 创建求解器组件 ==========
    Restrictor restrictor(left_type, right_type);;
    Prolongator prolongator;
    Smoother smoother(2.0/3.0, left_type, right_type);
    VCycle vcycle(restrictor, prolongator, smoother, left_type, right_type);
    FMG fmg(restrictor, prolongator, smoother, vcycle, left_type, right_type);
    
    // ========== 求解 ==========
    std::cout << "\nSolving..." << std::endl;
    std::vector<double> result;
    
    if (cycle_type == "FMG") {
        result = fmg.solve(b, grid, nu1, nu2);
    } else {
        result = u;
        for (int iter = 0; iter < max_iter; iter++) {
            result = vcycle.solve(result, b, grid, nu1, nu2);
            
            std::vector<double> Au = smoother.matVec(result, grid);
            double residual_norm = 0.0;
            for (size_t i = 0; i < Au.size(); i++) {
                double diff = b[i] - Au[i];
                residual_norm += diff * diff;
            }
            residual_norm = std::sqrt(residual_norm);
            
            if (residual_norm < epsilon) {
                std::cout << "  Converged after " << iter + 1 << " V-cycles" << std::endl;
                break;
            }
        }
    }
    
    // ========== 计算误差 ==========
    double error = computeError(result, grid, tf);
    std::cout << "\nResult:" << std::endl;
    std::cout << "  Max error = " << std::scientific << error << std::endl;
    
    // ========== 输出部分解 ==========
    std::cout << "\nSolution at selected points:" << std::endl;
    std::cout << std::fixed << std::setprecision(6);
    int step = n / 8;
    if (step < 1) step = 1;
    for (int i = 0; i <= n; i += step) {
        double x = grid->getX(i);
        double u_exact = tf.exact(x);
        std::cout << "  x = " << x << ": numerical = " << result[i] 
                  << ", exact = " << u_exact 
                  << ", error = " << std::abs(result[i] - u_exact) << std::endl;
    }
    return 0;
}
#include "VCycle.h"
#include "LinearSolver.h"
#include <iostream>
#include <cmath>
#include <iomanip>

std::vector<double> VCycle::solve(std::vector<double> u,
                                    const std::vector<double>& f,
                                    std::shared_ptr<Grid1D> grid,
                                    int nu1, int nu2) const {
    
    int n = grid->getN();
    int N_total = grid->getNumTotal();
    double h = grid->getH();
    
    // 调试：打印当前网格信息
    static int depth = 0;
    std::string indent(depth * 2, ' ');
    
    std::cout << indent << "VCycle: n = " << n << ", h = " << h << std::endl;
    std::cout << indent << "  left_type = " << left_type << ", right_type = " << right_type << std::endl;
    
    // 预平滑
    u = smoother(u, f, grid, nu1);
    
    // 最粗网格：直接求解
    if (grid->isCoarsest()) {
        std::cout << indent << "=== COARSEST GRID (n=" << n << ") ===" << std::endl;
        
        double inv_h2 = 1.0 / (h * h);
        
        std::vector<std::vector<double>> A(N_total, std::vector<double>(N_total, 0.0));
        std::vector<double> rhs = f;
        
        // 内部点
        for (int i = 1; i < n; i++) {
            A[i][i-1] = -inv_h2;
            A[i][i]   =  2.0 * inv_h2;
            A[i][i+1] = -inv_h2;
        }
        
        // 左边界
        if (left_type == "dirichlet") {
            A[0][0] = 1.0;
            std::cout << indent << "  Left: Dirichlet, rhs[0] = " << rhs[0] << std::endl;
        } else if (left_type == "neumann") {
            A[0][0] =  2*inv_h2;
            A[0][1] = -2*inv_h2;
            std::cout << indent << "  Left: Neumann, rhs[0] = " << rhs[0] << std::endl;
            std::cout << indent << "    A[0][0] = " << A[0][0] << ", A[0][1] = " << A[0][1] << std::endl;
        }
        
        // 右边界
        if (right_type == "dirichlet") {
            A[n][n] = 1.0;
            std::cout << indent << "  Right: Dirichlet, rhs[" << n << "] = " << rhs[n] << std::endl;
        } else if (right_type == "neumann") {
            A[n][n-1] = -2*inv_h2;
            A[n][n]   =  2*inv_h2;
            std::cout << indent << "  Right: Neumann, rhs[" << n << "] = " << rhs[n] << std::endl;
            std::cout << indent << "    A[" << n << "][" << n-1 << "] = " << A[n][n-1] 
                      << ", A[" << n << "][" << n << "] = " << A[n][n] << std::endl;
        }
        
        // 打印完整的矩阵和右端项（对于小网格）
        if (n <= 8) {
            std::cout << indent << "  Matrix A (" << N_total << "x" << N_total << "):" << std::endl;
            for (int i = 0; i < N_total; i++) {
                std::cout << indent << "    Row " << i << ": ";
                for (int j = 0; j < N_total; j++) {
                    std::cout << std::setw(10) << A[i][j] << " ";
                }
                std::cout << " | " << rhs[i] << std::endl;
            }
        }
        
        depth++;
        std::vector<double> result = LinearSolver::gaussianElimination(A, rhs);
        depth--;
        
        std::cout << indent << "  Coarse solution: ";
        for (int i = 0; i < N_total; i++) {
            std::cout << std::setw(10) << result[i] << " ";
        }
        std::cout << std::endl;
        
        return result;
    }
    
    depth++;
    
    // 计算残差
    std::vector<double> Au = smoother.matVec(u, grid);
    std::vector<double> r(N_total, 0.0);
    double r_norm = 0.0;
    for (int i = 0; i < N_total; i++) {
        r[i] = f[i] - Au[i];
        r_norm += r[i] * r[i];
    }
    r_norm = std::sqrt(r_norm);
    std::cout << indent << "  Residual norm before restriction: " << r_norm << std::endl;
    
    // 限制残差到粗网格
    auto coarse = grid->getCoarseGrid();
    std::vector<double> r_coarse = restrictor(r, grid, coarse);
    
    std::cout << indent << "  Coarse residual (first few): ";
    for (int i = 0; i < std::min(5, (int)r_coarse.size()); i++) {
        std::cout << r_coarse[i] << " ";
    }
    std::cout << std::endl;
    
    // 在粗网格上递归求解残差方程
    std::vector<double> e_coarse(coarse->getNumTotal(), 0.0);
    e_coarse = solve(e_coarse, r_coarse, coarse, nu1, nu2);
    
    // 延拓误差并校正
    std::vector<double> e = prolongator(e_coarse, coarse, grid);
    for (int i = 0; i < N_total; i++) {
        u[i] += e[i];
    }
    
    // 后平滑
    u = smoother(u, f, grid, nu2);
    
    depth--;
    
    return u;
}